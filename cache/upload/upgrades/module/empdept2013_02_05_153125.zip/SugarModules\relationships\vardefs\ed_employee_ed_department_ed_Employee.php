<?php
// created: 2013-02-05 14:58:49
$dictionary["ed_Employee"]["fields"]["ed_employee_ed_department"] = array (
  'name' => 'ed_employee_ed_department',
  'type' => 'link',
  'relationship' => 'ed_employee_ed_department',
  'source' => 'non-db',
  'vname' => 'LBL_ED_EMPLOYEE_ED_DEPARTMENT_FROM_ED_DEPARTMENT_TITLE',
);
