<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Master Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/en/msa/master_subscription_agreement_11_April_2011.pdf
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2011 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_TEAM' => 'Teams',
  'LBL_TEAMS' => 'Teams',
  'LBL_TEAM_ID' => 'Team ID',
  'LBL_ASSIGNED_TO_ID' => 'Toegewezen aan ID',
  'LBL_ASSIGNED_TO_NAME' => 'Toegewezen aan',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Datum ingevoerd',
  'LBL_DATE_MODIFIED' => 'Laatste wijziging',
  'LBL_MODIFIED' => 'Gewijzigd door',
  'LBL_MODIFIED_ID' => 'Gewijzigd door ID',
  'LBL_MODIFIED_NAME' => 'Gewijzigd door Naam',
  'LBL_CREATED' => 'Gemaakt door',
  'LBL_CREATED_ID' => 'Gemaakt door ID',
  'LBL_DESCRIPTION' => 'Beschrijving',
  'LBL_DELETED' => 'Verwijderd',
  'LBL_NAME' => 'Naam',
  'LBL_CREATED_USER' => 'Gemaakt door Gebruiker',
  'LBL_MODIFIED_USER' => 'Gewijzigd door Gebruiker',
  'LBL_LIST_NAME' => 'Naam',
  'LBL_ALT_ADDRESS' => 'Alt. Adres:',
  'LBL_FAX_PHONE' => 'Fax',
  'LBL_SALUTATION' => 'Aanhef',
  'LBL_FIRST_NAME' => 'Voornaam',
  'LBL_LAST_NAME' => 'Achternaam',
  'LBL_TITLE' => 'Titel',
  'LBL_DEPARTMENT' => 'Afdeling',
  'LBL_DO_NOT_CALL' => 'Niet Bellen',
  'LBL_HOME_PHONE' => 'Telefoon Thuis',
  'LBL_MOBILE_PHONE' => 'Telefoon Mobiel',
  'LBL_OFFICE_PHONE' => 'Telefoon Werk',
  'LBL_OTHER_PHONE' => 'Telefoon Anders',
  'LBL_EMAIL_ADDRESS' => 'E-mailadres(sen)',
  'LBL_PRIMARY_ADDRESS' => 'Primair Adres',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Straatnaam',
  'LBL_PRIMARY_ADDRESS_STREET_2' => 'Adres 2:',
  'LBL_PRIMARY_ADDRESS_STREET_3' => 'Adres 3:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Plaats',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Provincie',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Postcode',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Land',
  'LBL_ALT_ADDRESS_STREET' => 'Straatnaam',
  'LBL_ALT_ADDRESS_STREET_2' => 'Adres 2:',
  'LBL_ALT_ADDRESS_STREET_3' => 'Adres 3:',
  'LBL_ALT_ADDRESS_CITY' => 'Plaats',
  'LBL_ALT_ADDRESS_STATE' => 'Provincie',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Postcode',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Land',
  'LBL_COUNTRY' => 'Land',
  'LBL_STREET' => 'Ander Adres',
  'LBL_CITY' => 'Plaats',
  'LBL_STATE' => 'Provincie',
  'LBL_POSTALCODE' => 'Postcode',
  'LBL_POSTAL_CODE' => 'Postcode',
  'LBL_CONTACT_INFORMATION' => 'Contactinformatie',
  'LBL_ADDRESS_INFORMATION' => 'Adres(sen)',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Ander E-mailadres:',
  'LBL_ASSISTANT' => 'Assistent',
  'LBL_ASSISTANT_PHONE' => 'Telefoon Assistent',
  'LBL_WORK_PHONE' => 'Telefoon Werk',
  'LNK_IMPORT_VCARD' => 'Maak van vCard',
  'LBL_PICTURE_FILE' => 'Afbeelding',
  'LBL_LIST_FORM_TITLE' => 'Employee Lijst',
  'LBL_MODULE_NAME' => 'Employee',
  'LBL_MODULE_TITLE' => 'Employee',
  'LBL_HOMEPAGE_TITLE' => 'Mijn Employee',
  'LNK_NEW_RECORD' => 'Nieuwe Employee',
  'LNK_LIST' => 'Bekijk Employee',
  'LNK_IMPORT_ED_EMPLOYEE' => 'Import Employee',
  'LBL_SEARCH_FORM_TITLE' => 'Zoeken Employee',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Bekijk Historie',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activiteiten',
  'LBL_ED_EMPLOYEE_SUBPANEL_TITLE' => 'Employee',
  'LBL_NEW_FORM_TITLE' => 'Nieuw Employee',
  'LBL_EMPLOYEE_UNIQUE_ID' => 'Employee Unique ID',
);
?>
