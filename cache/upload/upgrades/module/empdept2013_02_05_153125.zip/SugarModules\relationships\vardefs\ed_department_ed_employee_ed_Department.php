<?php
// created: 2013-02-05 15:31:25
$dictionary["ed_Department"]["fields"]["ed_department_ed_employee"] = array (
  'name' => 'ed_department_ed_employee',
  'type' => 'link',
  'relationship' => 'ed_department_ed_employee',
  'source' => 'non-db',
  'vname' => 'LBL_ED_DEPARTMENT_ED_EMPLOYEE_FROM_ED_EMPLOYEE_TITLE',
);
